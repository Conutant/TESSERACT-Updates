Tesseract
===
Tesseract is a 100% free wordpress theme that allow you to make a website beautiful. 



= Features =

Hero Headline

The theme will have a main featured image with featued text and sub headline.  You can change the text and featured image right from the WordPress customizer.  The featured area will also be able to have buttons to change.  

Navgiation

The navigation will be able to be transpaernt on the homepage showing the featured image in the background.  You will also be able to change the font, font size, spacing, float and add buttons, text and social media. 



== Credits ==

* Tesseract was based on Underscores http://underscores.me/ - (C) 2012-2014 Automattic, Inc. - [GNU General Public License v2 or later]
* screenshot.png images: http://pixabay.com/en/man-person-shirt-bow-tie-suspender-407095/, http://pixabay.com/en/radio-television-grunge-chair-407112/, http://pixabay.com/en/wristwatch-watch-time-gadget-407096/ - [CC0] 
* /images/default-background.jpg http://www.pexels.com/photo/2286/ [CC0]
* /fonts/ http://typicons.com/ - (C) 2014 Stephen Hutchings - [SIL Open Font License]
